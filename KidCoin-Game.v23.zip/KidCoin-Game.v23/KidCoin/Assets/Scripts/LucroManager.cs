﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LucroManager : MonoBehaviour
{

    public UnityEngine.UI.Text iteminfo;
    public Click click;
    public float preco;
    public int tickValue;
    public int count;
    public string itemName;
    private float basePreco;

    private void Start()
    {
        basePreco = preco;
    }

    private void Update()
    {
        iteminfo.text = itemName + "\nPreço: " + preco;
    }

    public void PurchasedItem()
    {
        if (click.grana >= preco)
        {
            click.grana -= preco;
            count += 10;
            preco = Mathf.Round(basePreco + Mathf.Pow(1.410f, count));
        }
    }
}
