﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CharacterSelection : MonoBehaviour {

    public static CharacterSelection instance;

    private Personagem[] characterList;
    private int index;

    private void Start()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);

        characterList = new Personagem[transform.childCount];

        for (int i = 0; i < transform.childCount; i++)       
            characterList[i] = transform.GetChild(i).GetComponent<Personagem>();

        foreach (Personagem character in characterList)      
            character.gameObject.SetActive(false);

        if (characterList[0])
            characterList[0].gameObject.SetActive(true);

    }

    public Personagem GetSelectedCharacter()
    {
        return characterList[index];
    }

    public void SetaEsquerda()
    {
        characterList[index].gameObject.SetActive(false);

        index--;
        if (index < 0)
            index = characterList.Length - 1;

        characterList[index].gameObject.SetActive(true);
    }

    public void SetaDireita()
    {
        characterList[index].gameObject.SetActive(false);

        index++;
        if (index == characterList.Length)
            index = 0;

        characterList[index].gameObject.SetActive(true);
    }

    public void BotaoJogar()
    {
        SceneManager.LoadScene("GamePrincipal");
    }
}
