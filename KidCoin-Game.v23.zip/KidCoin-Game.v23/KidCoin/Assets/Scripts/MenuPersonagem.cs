﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class MenuPersonagem : MonoBehaviour {

    public GameObject[] Personagens;
   
    public Transform SpawnPoint;

    private int Personagem;


}
