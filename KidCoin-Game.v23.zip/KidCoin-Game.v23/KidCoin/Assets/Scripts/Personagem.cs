﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Personagem : MonoBehaviour
{
    public Sprite SpritePersonagem;
    public string Nome;
    
}
