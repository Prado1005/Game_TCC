﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Game : MonoBehaviour {

    public Image avatarPersonagem;

    public Text nomeJogadorText;

	// Use this for initialization
	void Start () {
        if (CharacterSelection.instance != null)
        {
            Personagem characterSelected = CharacterSelection.instance.GetSelectedCharacter();
            avatarPersonagem.sprite = characterSelected.SpritePersonagem;
            avatarPersonagem.color = Color.white;
        }

      nomeJogadorText.text = Cenas.instancia.nomeJogador;

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void BotaoMenu()
    {
        SceneManager.LoadScene("Menu");
    }
}
