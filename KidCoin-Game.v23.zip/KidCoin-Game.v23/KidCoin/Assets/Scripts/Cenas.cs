﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Cenas : MonoBehaviour {

    public static Cenas instancia;

    internal string nomeJogador = "Player Name";

    public InputField inputField;

	void Start () {
        if (instancia == null)
        {
            instancia = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
	}
	
	// Update is called once per frame
	public void AlterarNomeJogador () {
        nomeJogador = inputField.text;
    }
}
