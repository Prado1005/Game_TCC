﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuPausa : MonoBehaviour {

    
    public GameObject PanelMenu;
    public GameObject PanelInfo;
    public GameObject PanelPausa;
    public GameObject PanelCarta;
    public GameObject Menu;
    int counter;

    public void showHidePanel()
    {
        counter++;
        if (counter%1==1)
        {
            PanelMenu.gameObject.SetActive(false);
        }
        else
        {
            PanelMenu.gameObject.SetActive(true);
        }
        
    }

    public void showHideInfo()
    {
        counter++;
        if (counter % 1 == 1)
        {
            PanelInfo.gameObject.SetActive(false);
        }
        else
        {
            PanelInfo.gameObject.SetActive(true);
        }

    }

    public void showHidePausa()
    {
        counter++;
        if (counter % 1 == 1)
        {
            PanelPausa.gameObject.SetActive(false);
        }
        else
        {
            PanelPausa.gameObject.SetActive(true);
        }

    }


    public void showHideCarta()
    {
        counter++;
        if (counter % 1 == 1)
        {
            PanelCarta.gameObject.SetActive(false);
        }
        else
        {
            PanelCarta.gameObject.SetActive(true);
        }

    }

}
