﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Click : MonoBehaviour {
    public UnityEngine.UI.Text txtPoder;
    public UnityEngine.UI.Text txtGrana;
    public float grana = 0.00f  ;
    public int granaPorClick = 1;

    void Update()
    {
        txtGrana.text = "$ " + grana;
        txtPoder.text = granaPorClick + " grana/click";
    }

    public void Clicked()
    {
        grana += granaPorClick;
    }
}
