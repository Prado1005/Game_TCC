﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeManager : MonoBehaviour {

    public Click click;
    public UnityEngine.UI.Text itemInfo;
    public float preco;
    public int count = 0;
    public int clickPower;
    public string nomeItem;
    private float basePreco;

     void Start()
    {
        basePreco = preco;
    }

    void Update()
    {
        itemInfo.text = nomeItem + "\nPreço: " + preco + "\nPoder: +" + clickPower;    
    }

    public void PurchasedUpgrade()
    {
        if (click.grana >= preco)
        {
            click.grana -= preco;
            count += 1;
            click.granaPorClick += clickPower;
            preco = Mathf.Round (basePreco * Mathf.Pow(1.15f, count));
        }
    }
}
